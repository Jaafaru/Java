/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lecturehalllist;

/**
 *
 * @author whitehacker
 */
public class TutorialRoom {
    private String name;
    private String id;
    private String description;
    private String location;
    private String maximum_Capacity;
    private String currentStudentCapacity;
    private String electricalCondition;
    private String statusOfAvailability;
    
    public TutorialRoom(String name, String id, String description, String location, String maximum_Capacity, String currentStudentCapacity,
            String electricalCondition, String statusOfAvailability){
        this.name = name;
        this.id = id;
        this.description = description;
        this.location = location;
        this.maximum_Capacity = maximum_Capacity;
        this.currentStudentCapacity = currentStudentCapacity;
        this.electricalCondition = electricalCondition;
        this.statusOfAvailability = statusOfAvailability;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }

    public String getMaxiCapacity() {
        return maximum_Capacity;
    }

    public String getCurrentStudentCapacity() {
        return currentStudentCapacity;
    }

    public String getElectricalCondition() {
        return electricalCondition;
    }

    public String getStatusAvailability() {
        return statusOfAvailability;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setmaximum_Capacity(String maximum_Capacity) {
        this.maximum_Capacity = maximum_Capacity;
    }

    public void setCurrentStudentCapacity(String currentStudentCapacity) {
        this.currentStudentCapacity = currentStudentCapacity;
    }

    public void setElectricalCondition(String electricalCondition) {
        this.electricalCondition = electricalCondition;
    }

    public void setStatusOfAvailability(String statusOfAvailability) {
        this.statusOfAvailability = statusOfAvailability;
    }

    @Override
    public String toString() {
        return "TutorialRoom{" + "name=" + name + ", id=" + id + ", description=" + description + ", location=" + location + ", maximum_Capacity=" + maximum_Capacity + ", currentStudentCapacity=" + currentStudentCapacity + ", electricalCondition=" + electricalCondition + ", statusOfAvailability=" + statusOfAvailability + '}';
    }
    
    
    
}
