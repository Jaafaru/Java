/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lecturehalllist;

import java.util.Scanner;

/**
 *
 * @author whitehacker
 */
public class TutorialRoom_List {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String name, id, description, location, 
                electricalCondition, statusOfAvailability, maximumCapacity, currentStudentCapacity;
        int i, num;
        Scanner scan = new Scanner (System.in);
    
        System.out.println("Please Enter number of Tutorail Room: ");
        num = scan.nextInt();
        
        TutorialRoom TutorialRoom[] = new TutorialRoom[num];
        for(i=0; i < TutorialRoom.length; i++){
             System.out.println("Enter Room Name: ");
             name = scan.next();
             System.out.println("Enter Room id Number: ");
             id = scan.next();
             System.out.println("Enter Room Description: ");
             description = scan.next();
             System.out.println("Enter Room Location: ");
             location = scan.next();
             System.out.println("Enter Room Maximum Capacity: ");
             maximumCapacity = scan.next();
             System.out.println("Enter Room Current Student Capacity: ");
             currentStudentCapacity = scan.next();
             System.out.println("Enter Room Electrical Condition: ");
             electricalCondition = scan.next();
             System.out.println("Enter Room Status: ");
             statusOfAvailability = scan.next();
             
             TutorialRoom[i]= new TutorialRoom(name, id, description, location, maximumCapacity, currentStudentCapacity, electricalCondition, statusOfAvailability);
        }
        for(i=0; i < TutorialRoom.length; i++){
            System.out.println(""+TutorialRoom[i].toString());
            System.out.println("------------------------------------------------------");
        }
    }
    
}
