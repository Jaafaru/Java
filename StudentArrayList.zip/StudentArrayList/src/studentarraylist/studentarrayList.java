/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentarraylist;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author whitehacker
 */
public class studentarrayList {

    /**
     * @param args the command line arguments
     */
    static Scanner scan = new Scanner(System.in);
    static ArrayList<String> student = new ArrayList<String>();

    public static void main(String[] args) {
        // TODO code application logic here
        String name, delete;
            int i;
        System.out.println("Enter student name, Enter done when you are finish!");
        name = scan.next();
        
        // this line of code is use to keep adding names to the list until done is called
        while (!name.contains("done")) {
            student.add(name);
            name = scan.next();
        }
        displayname();

        // this is to delete a Name from the Arraylist
        System.out.println("Enter name to be deleted for the list");
        delete = scan.next();
        String u="";
        for (i = 0; i < student.size(); i++) {
            u=student.get(i);
            if (u.equalsIgnoreCase(delete)) {
                student.remove(i);
                break;
            }

        }
        displayname();
    }
    // Display list method
    public static void displayname() {
        System.out.println("-----------------------------------");

        for (String i : student) {
            System.out.println(i);
        }
        System.out.println("Array Size is: " + student.size());
    }
}
