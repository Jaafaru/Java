/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package school;

/**
*
* @author whitehacker
*/
public abstract class Student {
private String name;
private String matric;
private String address;
        String studtype;

public Student(String name, String matric, String address) {
    this.name = name;
    this.matric = matric;
    this.address = address;
}
public abstract void setStudType ();

public String getName() {
    return name;
}

public String getMatric() {
    return matric;
}

public String getAddress() {
    return address;
}

@Override
public String toString() {
    String stud = "";
    stud += "Name : " + name + "\n"
            + "MatriK No : " + matric + "\n"
            + "Address : " + address + "\n"
            + "StudentType : " + studtype + "\n"; 


    return stud;
}



}
