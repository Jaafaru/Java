/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package school;

/**
 *
 * @author whitehacker
 */
public class PhDCandidate extends Student {

    public PhDCandidate(String name, String matric, String address) {
        super(name, matric, address);
        
    }
    public void setStudType () {
    studtype = "PhDCandidate";
    }

    public String getStudtype() {
        return studtype;
    }
    
    
    
    
}
