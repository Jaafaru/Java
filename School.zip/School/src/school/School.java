/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package school;

/**
 *
 * @author whitehacker
 */
public class School {

    /**
     * @param args the command line arguments
     */
    private static Student stud [];
    private static Undergraduate ugstud;
    private static PhDCandidate pgstud;
    public static void main(String[] args) {
        // TODO code application logic here
        stud = new Student [5];
        adddata();
        loop();
        
         
    }
    public static void adddata (){ 
        stud[0] = new Undergraduate ("Ayo","225222","TM");
        stud[1] = new PhDCandidate ("Sunusi","657876","Proton");
        stud[2] = new PhDCandidate ("Hector","666231","Tradewinds");
        stud[3] = new Undergraduate ("Illo","214576","Misc");
        stud[4] = new PhDCandidate ("Haruna", "612345", "Tradewinds");
         for (int i = 0; i < stud.length; i++)
             stud[i].setStudType();
        
    }
    public static void polymorphicdisplay(int i){
        System.out.println(stud[i].toString());
    
    }
    public static void display (Student stud){
        System.out.println(stud.toString());
    }
    public static void disp (int i){
       if (stud[i].studtype.equalsIgnoreCase("UnderGraduate")) {
               ugstud = (Undergraduate)stud[i];
               display(ugstud);
       }
       
       else {
           pgstud = (PhDCandidate) stud[i]; 
             display(pgstud);   }   
       
    }
    public static void loop(){
        
    for (int i = 0; i < stud.length; i++) {
        System.out.println("Polymorphic Display");
        polymorphicdisplay(i);
        System.out.println("Non-Polymorphic Display");
        disp(i);
    
         }
    }
}
