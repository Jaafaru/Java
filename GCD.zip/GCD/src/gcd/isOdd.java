/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcd;

import java.util.Scanner;

/**
 *
 * @author jaafarmusa
 */
public class isOdd {
  

    public static boolean isOddNumber(int nom) {
        // This handles negative and positive odd numbers.
        return nom % 2 != 0;
    }
    public static void main(String[] args) {
        int nom;
        Scanner scan = new Scanner(System.in);
        System.out.println("Please Enter number: ");
        nom= scan.nextInt();
        if (isOddNumber(nom)) {
            System.out.println(nom+" is an Odd number");
        }
    }

}
