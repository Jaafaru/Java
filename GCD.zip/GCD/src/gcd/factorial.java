/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcd;
import java.io.*;
/**
 *
 * @author jaafarmusa
 */
public class factorial {
    

 public static int factorial(int num) {
if (num == 0)
 return 1;
 else
 return num*factorial(num-1);
 }
 public static void main (String[] args) throws IOException {
BufferedReader stdin= new BufferedReader( new InputStreamReader(System.in));
 int n, answer;
 System.out.println("Enter an integer:");
n=Integer.parseInt(stdin.readLine());
 answer = factorial(n);
 System.out.println("The factorial of " + n + " is " + answer);
 }

    
}
