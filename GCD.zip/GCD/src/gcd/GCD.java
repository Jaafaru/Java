/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcd;

import java.util.Scanner;

/**
 *
 * @author whitehacker
 */
public class GCD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //REQUIRES
        int a, b;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter first value: ");
        a = scan.nextInt();
        System.out.println("Enter first value: ");
        b = scan.nextInt();
        
        
       System.out.println("GCD of two numbers " + a +" and " + b +" is :" + gcd(a,b)); 
        
    } 
	//EFFECT
public static int gcd(int a, int b) {
		if (b == 0) {
			return a;
                         
		}
		else {
			return gcd(b, a%b); 
		}
	}
}
