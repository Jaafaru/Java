/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcd;

import java.util.Arrays;



/**
 *
 * @author whitehacker
 */
public class Sort {

    public static void main(String[] args)
	{
		Integer[] nom  = {2, 6, 3, 5, 1};
		mergeSort(nom);
		System.out.println(Arrays.toString(nom ));
	}

	public static void mergeSort(Comparable [ ] a)
	{
		Comparable[] tmp = new Comparable[a.length];
		mergeSort(a, tmp,  0,  a.length - 1);
	}


	private static void mergeSort(Comparable [ ] a, Comparable [ ] tmp, int first, int last)
	{
		if( first < last )
		{
			int center = (first + last) / 2;
			mergeSort(a, tmp, first, center);
			mergeSort(a, tmp, center + 1, last);
			merge(a, tmp, first, center + 1, last);
		}
	}


    private static void merge(Comparable[ ] a, Comparable[ ] tmp, int first, int last, int lastEnd )
    {
        int firstEnd = last - 1;
        int k = first;
        int num = lastEnd - first + 1;

        while(first <= firstEnd && last <= lastEnd)
            if(a[first].compareTo(a[last]) <= 0)
                tmp[k++] = a[first++];
            else
                tmp[k++] = a[last++];

        while(first <= firstEnd)    // Copy rest of first half
            tmp[k++] = a[first++];

        while(last <= lastEnd)  // Copy rest of right half
            tmp[k++] = a[last++];

        // Copy tmp back
        for(int i = 0; i < num; i++, lastEnd--)
            a[lastEnd] = tmp[lastEnd];
    }
}
