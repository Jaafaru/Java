/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcd;

import java.util.Arrays;

/**
 *
 * @author whitehacker
 */
public class Array {

    //
    public static void main(String args[]) {

        System.out.println("Sum of array elements is:" + sumOfArray());
    }

    public static double sumOfArray() {
        double[] num = {4.5, 3.4, 6.1, 5.3, 8.7, 9.2};
        double sum = 0;
        //Advanced for loop
        for (double i : num) {
            sum = sum + i;
        }

        return sum;
    }
}
