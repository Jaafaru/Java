/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uumbankingapplication;

/**
 *
 * @author whitehacker
 */
public class Account {
    //OVERVIEW: this is the Account class
    // it is mutable and inheritable
    //Account[accountnumber] is an integer
    //Account[customer] is a CustomerInfo
    //Account[balance] is a double

    private int accountnumber;
    private double balance;
    private CustomerRecord customer;


    public Account(CustomerRecord customer, double balance) {
        // if (this.accountnumber == 0){}
        this.accountnumber = GenAccNum.randomAccount();
        this.balance = 0.00;
        customer.setAccountBalance(balance);
        customer.setAccountnumber(accountnumber);
        this.customer = customer;
        // return this.accountnumber;
    }
     // public Account(int i){}

    public Account(CustomerRecord customer) { 
    // so as to work on created instance and not new every time
        this.accountnumber = customer.getAccountnumber();
        this.customer = customer;
    // return this.accountnumber;
    }

    public int getAccountNumber() { 
    //Effects: returns accountnumber
        return accountnumber;
    }

    public double getBalance() {
    //Effects: returns customer.getAccountBalance()
        return customer.getAccountBalance();
    }

    public void setBalance(double balance) {
        customer.setAccountBalance(balance);
        this.balance = balance;
    }

    public String getCustomerType() { 
    //Effects: returns customer.getAccountType();
        return customer.getAccountType();
    }

    public double deposit(double deposit) {
        //Requires:
        //Effects:
        double amount = 0.00;
        balance = this.getBalance();
        if ("Credit".equals(this.getCustomerType())) {
            CreditAcc acct = new CreditAcc(customer);
            amount = acct.deposit(deposit);
        } else {
            DebitAcc acct = new DebitAcc(customer);
            amount = acct.deposit(deposit);
        }
        return amount;
    }

    public double withdraw(double with) throws MinBalException {
        double amount = 0.00;
        balance = this.getBalance();
        if (with > balance) {
            throw new MinBalException("Withdrawal Limit Exceeded");
        }
        if ("Credit".equals(this.getCustomerType())) {
            CreditAcc acct = new CreditAcc(customer);
            amount = acct.withdraw(with);
        } else {
            DebitAcc acct = new DebitAcc(customer);
            amount = acct.withdraw(with);
        }
        return amount;
    }

    public void Setcust(String name, String add, String phone) {
        customer.setName(name);
        customer.setAddress(add);
        customer.setTelephone(phone);
        System.out.println("Succesfully updated");
    }

    @Override
    public String toString() {
        return "\n" + customer + "\n";
    }
}
