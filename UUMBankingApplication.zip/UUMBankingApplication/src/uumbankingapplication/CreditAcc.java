/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uumbankingapplication;

/**
 *
 * @author whitehacker
 */
public class CreditAcc extends Account {

    public CreditAcc(CustomerRecord customer) {
        super(customer);
    }

    public double deposit(double deposit) {
        double balance = super.getBalance();
        double amount = balance + deposit;
        super.setBalance(amount);
        return amount;
    }

    public double withdraw(double withd) throws MinBalException {
        double balance = super.getBalance();
        double amount = balance - withd - 20;
        if (amount < 0) {
            throw new MinBalException("Mininmum Balance Exceeded");
        }
        super.setBalance(amount);
        return amount;
    }
}
