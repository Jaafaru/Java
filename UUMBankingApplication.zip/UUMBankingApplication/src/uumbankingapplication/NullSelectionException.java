/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uumbankingapplication;

/**
 *
 * @author whitehacker
 */
public class NullSelectionException extends Exception {
    /**
     * Creates a new instance of <code>NullSelectionException</code> without
     * detail message.
     */
    public NullSelectionException() {
    }

    /**
     * Constructs an instance of <code>NullSelectionException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public NullSelectionException(String msg) {
        super(msg);
    }
}
