/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uumbankingapplication;

/**
 *
 * @author whitehacker
 */
import java.util.*;
public class AccountRecord {
    //OVERVIEW: the Storage representation to be used is an Arraylist
    //This class provides all the methods that are useful in modifiying the contents in the arraylist
    // Account is mutable
    //Abstraction Function
    //a.accounts[i].customer[name] is a string
    //a.accounts[i].customer[telephonne] is a string
    //a.accounts[i].customer[address is a string
    //a.accounts[i].customer[accounTtype] is a string
    //a.accounts[i].customer[balance] is a double
    //a.accounts[i].customer[accountnumber] is an integer
    // AF(a) = {a.accounts[i].customer | 0<=i<a.accounts.size}
    //The rep invariant is:
    // a.accounts != null &&
    // for all integers i.a.accounts[i].customer[accountnumber] is an integer &&
    // for all integers i, j.(0<=i<j<a.accounts.size)
    // a.accounts[i].customer[accountnumber] != a.accounts[j].customer[accountnumber]
    
    private ArrayList accounts;
    private int numb;
    public CustomerRecord customer;
    
    public AccountRecord() {
        //EFFECTS: Creates a new empty Arraylist accounts with a size of zero
        accounts = new ArrayList();
    }
    
    public AccountRecord(int no) {
        //EFFECTS: Creates a new object of AccountRecord to perform operations on the arraylist without initiating a new object of the class
    }
        //methods

    public boolean exists() { 
        // to check if an instance of accounts arraylist had been created
        //Effects: Checks if the accounts arraylist has been initialized
        // Returns true if not initialized and false if it has been initialized
        boolean exist = false;
        if (accounts == null) {
            exist = true;
        } //
        return exist;
    }

    public void addAccount(CustomerRecord customer) {
        //Requires: Requires an Object of CustomerRecord && customer != null
        //Modifies: Modifies Arraylist accounts by adding customer to the end of the accounts
        //Effects: Adds customer to the accounts arraylist. accounts.size() +1;
        // Displays new account number to the user
        accounts.add(new Account(customer, 0.00));
        int accnum = customer.getAccountnumber();
        System.out.println("Your Account as been Sucussfully added");
        System.out.println("Your Account Number is " + accnum);
        System.out.println("Current number of records " + accounts.size());
    }

    public String deposits(int accountNumber, double depAmount) {
        //Requires: Requires accountNumber to be integer and anAmount to be float.
        // ((accountNubmber && anAmount) != null))
        //Modifies: Modifies Arraylist accounts contents by adding anAmount to the balance of record customer with account number accountNumber
        //Effects: Updates the account balance of customer accountNumber in the arraylist accounts
        // if accountNumber exists returns new balance to the user else returns no such customer
        boolean found = false;
        double dep;
        double bal = 0;
        String results = "";
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext() && !found) {
            Account cust = (Account) iter.next();
            if (cust.getAccountNumber() == accountNumber) {
                dep = cust.deposit(depAmount);
                bal = cust.getBalance();
                found = true;  // stop the loop
            }
        }
        if (!found) {
            results = " No such customer";
        } else {
            results = "You have deposited a total of " + depAmount + " to your account and the new balance is " + bal;
        }
        return results;
    }

    public String withdraws(int accountNumber, double withAmount) throws MinBalException {
        //Requires: Requires accountNumber to be integer and anAmount to be float.
        // ((accountNubmber && anAmount) != null))
        //Modifies: Modifies Arraylist accounts contents by subtracting anAmount from the balance of record customer with account number accountNumber
        //Effects: Updates the account balance of customer accountNumber in the arraylist accounts
        // Throws MinimumBalanceException if anAmount > cust.getBalance();
        //if accountNumber exists returns new balance to the user else returns no such customer
        boolean found = false;
        double dep, bal = 0;
        String results = "";
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext() && !found) {
            Account cust = (Account) iter.next();
            if (cust.getAccountNumber() == accountNumber) {
                dep = cust.withdraw(withAmount);
                bal = cust.getBalance();
                found = true; // stop the loop
            }
        }
        if (!found) {
            results = " No such customer";
        } else {
            results = "You have withdrawed a total of " + withAmount + " from your account and the new balance is " + bal;
        }
        return results;
    }

    public String balance(int accountNumber) {
        //Requires: Requires accountNumber to be integer
        // accountNumber != null
        //Effects: Returns the account balance of customer accountNumber in the arraylist accounts
        //if accountNumber exists returns balance to the user else returns no such customer
        boolean found = false;
        double balance = 0;
        String results = "";
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext() && !found) {
            Account cust = (Account) iter.next();
            if (cust.getAccountNumber() == accountNumber) {
                balance = cust.getBalance();
                found = true; // stop the loop
            }
        }
        if (!found) {
            results = " No such customer";
        } else {
            results = "Your current balance is " + balance;
        }
        return results;
    }

    public String deleteAccount(int accountNumber) {
        //Requires: Requires accountNumber to be integer
        // accountNubmber != null
        //Modifies: Modifies Arraylist accounts by removing customer record with account number accountNumber
        //Effects: Remove record of customer accountNumber from arraylist accounts
        //if accountNumber exists and the balnce is empty returns removed record
        //if accountNumber exists and the balnce is not empty returns unremoved record because of available balance
        //Returns no such customer if account number is not found
        boolean found = false;
        String results = "";
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext() && !found) {
            Account cus = (Account) iter.next();
            if (cus.getAccountNumber() == accountNumber) {
                found = true; // there is a match, stop the loop
                if (cus.getBalance() == 0) {
                    iter.remove(); // remove this BankAccount object
                    results = "Account number " + accountNumber + " has been removed";
                } else {
                    results = "Account number " + accountNumber + " cannot be removed as it has a balance of " + cus.getBalance();
                }
            } //end if there is a match
        } // end while loop
        if (!found) {
            results = " No such account";
        }
        return results;
    }

    public void displayall() {
        //EFFECTS: Returns all record in the Arraylist accounts else returns empty if accounts is emtpy
        boolean confirm = false;
        System.out.println("The List of all customers in the bank with their Informations");
        System.out.println("There is a total of " + accounts.size() + " accounts in the bank record");
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext()) {
            Account c = (Account) iter.next();
            System.out.println(c);
            confirm = true;
        } // end while loop
        if (confirm == false) {
            System.out.println(" No bank record available");
        }
        //return confirm;
    }

    public boolean search(int accountNumber) {
        //Requires: Requires accountNumber to be integer
        // accountNubmber != null
        //Modifies:
        //Effects: Returns true if the accountNumber exist in the records of arrayLists accounts
        boolean confirm = false;
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext() && !confirm) {
            Account c = (Account) iter.next();
            int accountno = c.getAccountNumber();
            if (accountNumber == accountno) {
                confirm = true; // there is a match, stop the loop
            } //end if there is a match
        } // end while loop
        return confirm;
    }

    public void searchAcc(int accountNumber) {
        //Requires: Requires accountNumber to be integer
        // accountNubmber != null
        //Modifies:
        //Effects: Print Account number details if the accountNumber exist in the records of arrayLists accounts
        // Prints No such Account Number Exists if the account number doesnt exist in the customer record in arraylist accounts
        boolean confirm = false;
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext() && !confirm) {
            Account c = (Account) iter.next();
            int accountno = c.getAccountNumber();
            if (accountNumber == accountno) {
                confirm = true; // there is a match, stop the loop
                System.out.println("Account Number Details");
                System.out.println(c);
            } //end if there is a match
        } // end while loop
        if (confirm == false) {
            System.out.println("No such Account Number Exists");
        }
    }

    public void update(String name, String add, String phone, int acc) {
        //Requires: Requires accountNumber to be integer
        // accountNubmber != null
        //Modifies: customer details of account Number accc in the arraylist accounts
        //Effects: Print updated Account number details if the accountNumber exist in the records of arrayLists accounts
        // Prints No such Account Number Exists if the account number doesnt exist in the customer record in arraylist accounts
         boolean confirm = false;
        ListIterator iter = accounts.listIterator();
        while (iter.hasNext() && !confirm) {
            Account c = (Account) iter.next();
            int accountno = c.getAccountNumber();
            if (acc == accountno) {
                confirm = true; // there is a match, stop the loop
                c.Setcust(name, add, phone);
                System.out.println("Updated Customer Details");
                System.out.println(c);
                confirm = true;
            } //end if there is a match
        } // end while loop
        if (confirm == false) {
            System.out.println("No such Account Number Exists");
        }
    }

    
}
