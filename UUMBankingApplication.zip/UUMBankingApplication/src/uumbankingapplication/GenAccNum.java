/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uumbankingapplication;

import java.util.Random;

/**
 *
 * @author whitehacker
 */
public class GenAccNum {
    //Overview: Generate account is used to generate random account number for the customer details class

    public static int randomAccount() {
//Effects:Generate a new account number for every new customer
// checks if the account number does not exist
// Returns newly generated account number
        int low = 100000, high = 999999;
        Random acc = new Random();
        int randAcc = 0;
        boolean rhyme = false;
        boolean exist = false;
        AccountRecord AccRec = new AccountRecord(1);
        if (AccRec.exists() == true) {
            randAcc = acc.nextInt((high - low) + 1) + low;
        } else {
            rhyme = AccRec.search(randAcc);
        }
        if (rhyme == true) {
            randAcc = acc.nextInt((high - low) + 1) + low;
        }
//if(randAcc)
        return randAcc;
    }
}
