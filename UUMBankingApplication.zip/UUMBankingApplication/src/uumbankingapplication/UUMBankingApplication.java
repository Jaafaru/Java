/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uumbankingapplication;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author whitehacker
 */
public class UUMBankingApplication {

    /**
     * @param args the command line arguments
     */
     static UUMBankingApplication uum = new UUMBankingApplication();
    static Scanner scan = new Scanner(System.in); // Stream for reading User Input;
    AccountRecord accountrecord = new AccountRecord();//
    public static void main(String[] args) {
      // Effects: Dispaly user selection menu for the bank application
        uum.dispalyMenu();
    }
    //methods

    public void dispalyMenu() {
        // Effects: Displays the Client menu for the bank application
        //throws InputMismacthException if the selected option is not an integer
        // throws NullSelectionException if range of selection usis not selected
        int option = 0;
        boolean loop = true, loop1 = true;
        System.out.println("***********************************************************");
        System.out.println("*********** Welcome to UUM Banking Application ************");
        System.out.println("***********************************************************");
        System.out.println("* Enter \"1\" to Create a new account                       *");
        System.out.println("* Enter \"2\" to Deposit Money                              *");
        System.out.println("* Enter \"3\" to Withdraw Money                             *");
        System.out.println("* Enter \"4\" to Check Balance                              *");
        System.out.println("* Enter \"5\" to Search for an Account Details              *");
        System.out.println("* Enter \"6\" to Delete Account                             *");
        System.out.println("* Enter \"7\" to Get Number and Details of Current Records  *");
        System.out.println("* Enter \"8\" to Update a Customer Detail                   *");
        System.out.println("* Enter \"0\" to Exit application                           *");
        System.out.println("***********************************************************");
        int numb;
        while (loop) {
            try {
                option = scan.nextInt();
                if ((option > 8) || (option < 0)) {
                    throw new NullSelectionException("wrong menu selection");
                }
                loop = false;
            } catch (NullSelectionException ex) {
                System.out.println(ex.getMessage());
                String str = scan.next();
                loop = true;
            } catch (InputMismatchException ex) {
                System.out.println("Enter a Number within the range");
                String str = scan.next();
                loop = true;
            }
        }// while loop
        System.out.println("Number " + option+ " was Selected ");
        // Project pr = new Project();
        if (option == 0) {
            uum.exitAPP();
        }
        if (option == 1) {
            uum.createCustomer();
        }
        if (option == 2) {
            uum.makeDeposit();
        }
        if (option == 3) {
            uum.makeWithdraw();
        }
        if (option == 4) {
            uum.checkBal();
        }
        if (option == 5) {
            uum.searchAccount();
        }
        if (option == 6) {
            uum.deleteAccount();
        }
        if (option == 7) {
            uum.getAllRecord();
        }
        if (option == 8) {
            uum.updateCustomer();
        }
    }

    public void createCustomer() {
        // Effects: Add a new customer in the bank application
        //throws InputMismatchException if the selected option is not an integer
        // throws AccountTypeException if range Account type is not selected
        boolean loop = true, loop1 = true;
        String name;
        int acctype = 0;
        String telephone;
        String address;
        String type = "";
        int accountnumber;
        double balance;
        System.out.println("To create an account, You would need to fill in your details as required. \nThe account Number would by automatically generated. ");
        System.out.println("Please Enter your Name:");
        name = scan.next();
        System.out.println("Please Enter your Address:");
        address = scan.next();
        while (loop) {
            try {
                System.out.println("Please Select Account type Between Credit and Debit. \nEnter 1 for Credit and 2 for Debit:");
                acctype = scan.nextInt();
                if ((acctype != 1) && (acctype != 2)) {
                    throw new AcctTypeException("Wrong account Type Please Select 1 or 2 ");
                }
                System.out.println("Your account type is " + acctype);
                loop = false;
                if (acctype == 1) {
                    type = "Credit";
                } else {
                    type = "Debit";
                }
            } catch (AcctTypeException ex) {
                System.out.println(ex.getMessage());
                String str = scan.next();
                loop = true;
            } catch (InputMismatchException ex) {
                System.out.println("Enter a number between 1 and 2");
                String str = scan.next();
                loop = true;
            }
        //|| (type != "Debit")
        }// loop
        System.out.println("Enter your Telephone Number:");
        telephone = scan.next();
        CustomerRecord ci = new CustomerRecord(name, telephone, address, type, 0, 0.00);
        accountrecord.addAccount(ci);
        uum.dispalyMenu();
    }

    public void makeDeposit() {
        // Effects: Deposit amount to customer account in the bank application
        //throws InputMismatchException if the account number and deposit is not integer
        int accountno = 0;
        int amt = 0;
        System.out.println("Please Enter your Account Number:");
        boolean loop = true, loop1 = true;
        while (loop) {
            try {
                accountno = scan.nextInt();
                loop = false;
            } catch (InputMismatchException ex) {
                System.out.println("Please Enter an Integer for account number:");
                String str = scan.next();
                loop = true;
            }
        }//catch loop
        System.out.println("Please Enter The amount to be deposited:");
        while (loop1) {
            try {
                amt = scan.nextInt();
                loop1 = false;
            } catch (InputMismatchException ex) {
                System.out.println("Please Enter an Integer for the amount:");
                String str = scan.next();
                loop1 = true;
            }
        }//catch loop1
        System.out.println(accountrecord.deposits(accountno, amt));;
        uum.dispalyMenu();
    }

    public void makeWithdraw() {
        // Effects: Withdraw amount from customer in the bank application
        //throws InputMismatchException if the account number and withdrawal is not integer
        // throws MinimumBalanceException if withdraw is greater than the remaining balance
        int accountno = 0, withd = 0;
        System.out.println("Please Enter your Account Number:");
        boolean loop = true;
        while (loop) {
            try {
                accountno = scan.nextInt();
                loop = false;
            } catch (InputMismatchException ex) {
                System.out.println("Please Enter an Integer for account number:");
                String str = scan.next();
                loop = true;
            }
        }//catch loop
        System.out.println("Please Enter Amount To Withdraw");
        boolean loop1 = true;
        while (loop1) {
            try {
                withd = scan.nextInt();
                loop1 = false;
                try {
                    System.out.println(accountrecord.withdraws(accountno, withd));
                } catch (MinBalException ex) {
                    System.out.println(ex.getMessage());
                    String str = scan.next();
                    loop1 = true;
                }
            } catch (InputMismatchException ex) {
                System.out.println("Please Enter an Integer for account number:");
                String str = scan.next();
                loop = true;
            }
        }//catch loop
        uum.dispalyMenu();
    }

    public void checkBal() {
        // Effects: Checks if an account exist
        //throws InputMismatchException if the account number is not an integer
        int accountno = 0;
        System.out.println("Please Enter your Account Number:");
        boolean loop = true;
        while (loop) {
            try {
                accountno = scan.nextInt();
                System.out.println(accountrecord.balance(accountno));
                loop = false;
            } catch (InputMismatchException ex) {
                System.out.println("Please Enter an Integer for account number:");
                String str = scan.next();
                loop = true;
            }
        }//catch loop
        uum.dispalyMenu();
    }

    public void searchAccount() {
        // Effects: Search for the details of an account number
        //throws InputMismatchException if the account number is not an integer
        int accountno = 0;
        System.out.println("Please Enter your Account Number:");
        boolean loop = true;
        while (loop) {
            try {
                accountno = scan.nextInt();
                accountrecord.searchAcc(accountno);
                loop = false;
            } catch (InputMismatchException ex) {
                System.out.println("Please Enter an Integer for account number:");
                String str = scan.next();
                loop = true;
            }
        }//catch loop
        uum.dispalyMenu();
    }

    public void deleteAccount() {
        // Effects: Remove a customer in the bank application
        //throws InputMismatchException if the account number is not an integer
        int accountno = 0;
        System.out.println("Please Enter your Account Number:");
        boolean loop = true;
        while (loop) {
            try {
                accountno = scan.nextInt();
                System.out.println(accountrecord.deleteAccount(accountno));
                loop = false;
            } catch (InputMismatchException ex) {
                System.out.println("Please Enter an Integer for account number:");
                String str = scan.next();
                loop = true;
            }
        }//
        uum.dispalyMenu();
    }

    public void getAllRecord() {
        // Effects: Display all records in the bank application
        accountrecord.displayall();
        uum.dispalyMenu();
    }

    public void updateCustomer() {
        // Effects: Update a customer detail
        //throws InputMismatchException if the accunt number is not an integer
        boolean loop = true;
        String name;
        String telephone;
        String address;
        int accountnumber = 0;
        while (loop) {
            try {
                System.out.println("Please Enter your Account Number:");
                accountnumber = scan.nextInt();
                loop = false;
            } catch (InputMismatchException ex) {
                System.out.println("Enter a number:");
                String str = scan.next();
                loop = true;
            }
        }// loop
        System.out.println("Please Enter your New Name:");
        name = scan.next();
        System.out.println("Please Enter your New Address:");
        address = scan.next();
        System.out.println("Enter your Telephone Number:");
        telephone = scan.next();
        accountrecord.update(name, address, telephone, accountnumber);
        uum.dispalyMenu();
    }

    public void exitAPP() {
        System.out.println("Thank you for banking with us!");
        System.exit(0);
        
        
    }
}
