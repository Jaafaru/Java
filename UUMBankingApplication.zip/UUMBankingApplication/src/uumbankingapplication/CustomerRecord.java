/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uumbankingapplication;

/**
 *
 * @author whitehacker
 */
public class CustomerRecord {
    //OVERVIEW: this is the customer class
    // it is mutable
    //CustomerInfo[accountnumber] is an integer
    //CustomerInfo[name] is a string
    //CustomerInfo[telephone] is a string
    //CustomerInfo[address] is a string
    //CustomerInfo[accountType] is a string
    //CustomerInfo[balance] is a double

    private String name;
    private String telephone;
    private String address;
    private String accountType;
    private int accountnumber;
    private double balance;
       //Constructor

    public CustomerRecord(String name, String telephone, String address, String accountType, int accountnumber, double balance) {
        //Requires: name, telephone, address, accountType to be String, accountnumber to be Integer, balance to be double
        // (name && telephone && address && accounTtype && accountnumber && balance ) != null
        //Modifies: this.name, this.telephone, this.address, this.accountType, this.accountnumber, this.balance
        //Effects: Creates a new object of Customer
        // changes this.name = name;
        // changes this.telephone = telephone;
        // changes this.address = address;
        // changes this.accountType = accountType;
        this.name = name;
        this.telephone = telephone;
        this.address = address;
        this.accountType = accountType;
    }
        //methods

    public void setName(String name) {
        //modifies: this.name
        //effects: changes the value of this.name = name
        this.name = name;
    }

    public String getName() {  
        //Effects: Returns name
        return name;
    }

    public void setAccountnumber(int accountnumber) {
        //Requires: accountnumber to be integer
        //modifies: this.accountnumber
        //effects: changes the value of this.accountnumber = accountnumber
        this.accountnumber = accountnumber;
    }

    public int getAccountnumber() { 
        //Effects: Returns accountnumber
        return accountnumber;
    }

    public void setAccountBalance(double balance) {
        //Requires: balance to be double
        //modifies: this.balance
        //effects: changes the value of this.balance = balance
        this.balance = balance;
    }

    public double getAccountBalance() { 
        //Effects: Returns balance
        return balance;
    }

    public void setTelephone(String telephone) {
        //modifies: this.telephone
        //effects: changes the value of this.telephone = telephone
        this.telephone = telephone;
    }

    public String getTelephone() { 
        //Effects: Returns telephone
        return telephone;
    }

    public void setAddress(String address) {
        //modifies: this.address
        //effects: changes the value of this.address = address
        this.address = address;
    }

    public String getAddress() { 
        //Effects: Returns address
        return address;
    }

    public void setAccountType(String accountType) {
        //modifies: this.accountType
        //effects: changes the value of this.accountType = accountType
        this.accountType = accountType;
    }

    public String getAccountType() { 
        //Effects: Returns accountType
        return accountType;
    }

    public String toString() {
        //effects: Returns a well formatted string that print the details about the CustomerRecord object
        return "\n" + "Name of Customer: " + name + "\nTelephone Number: " + telephone + "\nAddress: " + address + "\nAccount Type: " + accountType + " \nAccount Number : " + accountnumber + " \nAvailable Balance : " + balance;
    }
}
