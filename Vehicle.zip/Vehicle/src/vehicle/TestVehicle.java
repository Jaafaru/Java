/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

import java.util.Scanner;

/**
 *
 * @author whitehacker
 */
public class TestVehicle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Vehicle v;

        try {
            System.out.println("--------------------------------------");
            v = new Bicycle("Bic001", "green", 700);
            System.out.println(v);
            v.move();
            v.turn();
            System.out.println("--------------------------------------");
            v = new Bus("bus001", "red", "Toyota", "Corolla", "auto");
            System.out.println(v);
            v.move();
            v.turn();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

}
