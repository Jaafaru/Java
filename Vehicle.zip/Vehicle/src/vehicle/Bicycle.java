/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *
 * @author whitehacker
 */
public class Bicycle extends Vehicle {

    int frameSize;

    public Bicycle(String VehicleId, String color, int frameSize) throws Exception {
        super(VehicleId, color);
        this.frameSize = frameSize;
    }

    public int getFrameSize() {
        return frameSize;
    }

    public void move() {
        System.out.println("Bicycle move operation: pedal.");
    }

    public void turn() {
        System.out.println("Bicycle turn operation: use the handlebars.");
    }

    @Override
    public String toString() {
        return "Bicycle{ " + super.toString() + "frameSize = " + frameSize + '}';
    }

}
