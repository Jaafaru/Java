/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *
 * @author whitehacker
 */
public abstract class Vehicle {

    String VehicleId;
    String color;

    public Vehicle(String VehicleId, String color) throws Exception {
        this.VehicleId = VehicleId;
        this.color = color;

    }

    public String getVehicleId() {
        return VehicleId;
    }

    public String getColor() {
        return color;
    }

    public abstract void move();

    public abstract void turn();

    @Override
    public String toString() {
        return "VehicleId = " + VehicleId + ", color = " + color + ", ";
    }

}
