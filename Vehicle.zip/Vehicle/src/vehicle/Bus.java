/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *
 * @author whitehacker
 */
public class Bus extends Vehicle {

    String brand;
    String model;
    String transmissionGear;

    public Bus(String VehicleId, String color, String brand, String model, String transmissionGear) throws Exception {
        super(VehicleId, color);
        this.brand = brand;
        this.model = model;
        this.transmissionGear = transmissionGear;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public String getTransmissionGear() {
        return transmissionGear;
    }

    public void move() {
        System.out.println("Bus move operation: step on the accelerator.");
    }

    public void turn() {
        System.out.println("Bus turn operation: use the steering wheel");
    }

    @Override
    public String toString() {
        return "Bus{ " + super.toString() + "brand = " + brand + ", model = " + model + ", transmissionGear = " + transmissionGear + '}';
    }

}
