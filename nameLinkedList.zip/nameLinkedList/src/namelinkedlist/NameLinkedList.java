/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namelinkedlist;

import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author whitehacker
 */
public class NameLinkedList {

    static LinkedList student = new LinkedList();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        String name, delete;
        int i;
        System.out.println("Enter student name, Enter done when you are finish!");
        name = in.next();
        
        // this line of code is use to keep adding names to the list until done is called
        while (!name.contains("done")) {
            student.add(name);
            name = in.next();
        }
        displaylist();
        
        // this is to delete a Name from the Linkedlist
        System.out.println("Enter the name that you want to delete for the Linkedlist");
        delete = in.next();
        String u = "";
        for (i = 0; i < student.size(); i++) {
            u = (String) student.get(i);
            if (u.equalsIgnoreCase(delete)) {
                student.remove(i);
                break;
            }

        }
        displaylist();

    }
    //Display list Method
    public static void displaylist() {
        System.out.println("-----------------------------------");

        for (Object i : student) {
            System.out.println(i);
        }
        System.out.println("The size of the Linkedlist is: " + student.size());
    }
}
