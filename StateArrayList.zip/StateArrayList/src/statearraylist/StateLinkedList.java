/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package statearraylist;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author jaafarmusa
 */
public class StateLinkedList {
    static LinkedList state = new LinkedList();
    
    public static void main(String[] args) {
        // TODO code application logic here

        state.add("Ondo");
        state.add("Lagos");
        state.add("Oyo");
        state.add("Osun");
        state.add("Ogun");
        state.add("Abuja");
        state.add("Kaduna");
        state.add("Kano");

        liststate();

        state.remove("Ondo");
        state.remove("Oyo");
        state.remove("Ogun");
        state.remove("Kaduna");
        
        liststate();
    }

    public static void liststate() {
        System.out.println("");
        System.out.println("List of states in Nigeria using Linkedlist");
        Iterator itr = state.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next() + " State");
        }
         System.out.println("Linkedlist size is: " + state.size());
    }

}
