
package statearraylist;

import java.util.Iterator;
import java.util.Vector;
public class StateVector {
 static Vector<String> state = new Vector<String>();  

public static void main(String[] args) {
        // TODO code application logic here

        state.addElement("Ondo");
        state.addElement("Lagos");
        state.addElement("Oyo");
        state.addElement("Osun");
        state.addElement("Ogun");
        state.addElement("Abuja");
        state.addElement("Kaduna");
        state.addElement("Kano");

        liststate();

        state.remove("Ondo");
        state.remove("Oyo");
        state.remove("Ogun");
        state.remove("Kaduna");
        
        liststate();
    }

    public static void liststate() {
        System.out.println("");
        System.out.println("List of states in Nigeria using Vector");
        Iterator itr = state.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next() + " State");
        }
         System.out.println("Vector size is: " + state.size());
    }
 
}
