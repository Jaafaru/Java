
package statearraylist;

import java.util.HashMap;

public class StateHashMap {
    
    public static void main(String[] args) {
        
        HashMap state = new HashMap();
        state.put(1, "Ondo");
        state.put(2, "Lagos");
        state.put(3, "Oyo");
        state.put(4, "Osun");
        state.put(5, "Ogun");
        System.out.println("Initial elements in the map list: " + state);
        System.out.println(" ");
        System.out.println("Size of the map list: " + state.size());
        System.out.println(" ");

        state.remove(3);
        state.remove(5);

        System.out.println("Map list elements after removing element 3 and 5: " + state);
        System.out.println(" ");
        System.out.println("Size of the map list: " + state.size());

    }
}
