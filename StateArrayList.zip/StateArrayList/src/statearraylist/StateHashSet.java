
package statearraylist;

import java.util.HashSet;
import java.util.Iterator;

public class StateHashSet {
    static HashSet<String> state = new HashSet<String>();
    public static void main(String[] args) {

       state.add("Ondo");
        state.add("Lagos");
        state.add("Oyo");
        state.add("Osun");
        state.add("Ogun");
        state.add("Abuja");
        state.add("Kaduna");
        state.add("Kano");

        liststate();

        state.remove("Ondo");
        state.remove("Oyo");
        state.remove("Ogun");
        state.remove("Kaduna");
        
        liststate();
    }
    
    public static void liststate() {
        System.out.println("");
        System.out.println("List of states in Nigeria using HashSet");
        Iterator itr = state.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next() + " State");
        }
         System.out.println("HashSet size is: " + state.size());
    }
    
    
}
