
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Scanner;
import javax.swing.JOptionPane;
/**
 *
 * */
public class TestEmployee {

    /**
     * @param args the command line arguments
     */
    static Scanner in = new Scanner(System.in); // declaration of Scanner
    private static Employee emp; // declaration of employee
    private static LinkedList<Employee> list = new LinkedList<Employee>(); // declaration of linkedlist
    // declaration of variables
    static String staffID, name,gender,adress, department, post,dob;
    static double salary;
    static int count = 0;
    public static void main(String[] args) {
        
        imports();
        int choice;       
        choice = menu ();
        
        while (choice == 1) {  
        add (); 
        //write ();
        System.out.println("");
        choice = menu ();
         }
        if (choice == 2){
          show(); }
        if (choice == 3) {
        System.out.println("Cleared!!");
        list.clear(); }
        write ();
    }
    // function to display menu options
        public static int menu ( ) {
         int choice;
        System.out.println("======================================= ");
        System.out.println("      AHMED AND ABDULAZEEZ ENTERPRISE");
        System.out.println("======================================= \n");
        System.out.println("1 - Add Staff Info: ");
        System.out.println("2 - Display Staff Info & Exit");
        System.out.println("3 - Clear list & Exit\n");
        System.out.print("                      Your Choice ==> :");
        choice = in.nextInt(); 
        System.out.println("========================================\n");
        return choice; 
         } 
        
        // Function to get input for user
        public static void add ( ) {
        System.out.println("Please Enter StaffId: ");
        staffID = in.next();
        System.out.println("Please Enter Staff Name: ");
        name = in.next() +in.nextLine();
        System.out.println("Please Enter Staff Gender: ");
        gender = in.next();
        System.out.println("Please Enter Staff Adress: ");
        adress = in.next();
        System.out.println("Please Enter Staff Department: ");
        department = in.next();
        System.out.println("Please Enter Staff Position: ");
        post = in.next()+in.nextLine();
        System.out.println("Please Enter Date of Birth: ");
        dob = in.next();
        System.out.println("Please Enter Salary: ");
        salary = in.nextDouble();
        emp = new Employee(staffID, name, gender, adress, department, post, dob, salary);
        list.add(emp);
        ++count; 
        }
        
        // Function to validate if staff file is empty
        public static void display (){
        if (!list.isEmpty()) {
            show();
        } else {
            System.out.println("List is empty.");
        }
        }
        
        // Function to display user details from the staff file
        public static void show(){
         try {
              
             if (list.size()==0){
               JOptionPane.showMessageDialog(null,"Staff List is EMPTY");
             }
             else {
                 String d = "______________________________________________________________________________________________________________________________";
                 System.out.println(d);
                 System.out.printf("%-6s %-20s %-12s %-10s %-12s %-20s %-10s %-10s %n","ID","Name","Gender","Address","Department","Position","Salary","DOB");
                 System.out.println(d);
              for (Employee staff : list){
                 staff.displayInformation();    
                }
            
                
             }
            
            }  catch (Exception err) {
                  JOptionPane.showMessageDialog(null, "System Error!!", "ERROR", 0);  
                    }  
        }
        
       // Function to send user input to the staff file
         public static void imports () {
        try {
              // Staff file location or directory
                 File directory_data = new File("/Users/jaafarumusa/Downloads/Employee/src/employee/staff_file.dat");
                // FileOutputStream outFileStream = new FileOutputStream (directory_data);
                // PrintWriter save_data = new PrintWriter(outFileStream);
                  if (directory_data.exists()) {
                   
//                    BufferedReader read_data = new BufferedReader(reader);
//                    FileReader reader = new FileReader(directory_data);
                
                Scanner ayo = new Scanner(directory_data);
                while (ayo.hasNextLine()){
                staffID = ayo.nextLine();
                name = ayo.nextLine();
                gender = ayo.nextLine();
                adress = ayo.nextLine();
                department = ayo.nextLine();
                post = ayo.nextLine();
                dob = ayo.nextLine();
                salary = Double.parseDouble(ayo.nextLine());
                emp = new Employee (staffID, name, gender, adress, department, post, dob, salary);
                list.add(emp);++count;
                } 
//                 read_data.close();
                 ayo.close(); 
                 }
         
               

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "System Error!!", "ERROR", 0);
                        ex.printStackTrace();
                          }
        
    }
         
         // Funtion to get user input from staff file 
         public static void write () {
          try {          String staffID, name, gender, adress, department, post, dob;
                          double salary;      
                   File directory_data = new File("/Users/jaafarumusa/Downloads/Employee/src/employee/staff_file.dat");
                   // declarating FileOutputStream
                   FileOutputStream outFileStream = new FileOutputStream (directory_data); 
                   // declarating PrintWriter
                   PrintWriter save_data = new PrintWriter(outFileStream);
              if (list.size()!= 0) {
                   for (Employee staff : list){
                     staffID = staff.getStaffID();
                     name = staff.getName();
                     gender = staff.getGender();
                     adress =staff.getAdress();
                     department = staff.getDepartment();
                     post = staff.getPost();
                     dob = staff.getDob();
                     salary = staff.getSalary();
                    save_data.println(staffID);
                    save_data.println(name);
                    save_data.println(gender);
                    save_data.println(adress);
                    save_data.println(department);
                    save_data.println(post);
                    save_data.println(dob);
                    save_data.println(salary+"");
                   }
    
          save_data.close();  }
          
    } catch (Exception err) {
    
    }
         }
         
}
