/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 *
 */
public class Employee {
//variables
   private String staffID,name,gender,adress,department, post ,dob;
   private int employeeType;
   private double basicSalary,salary;
   
   //methods

    public Employee(String staffID, String name, String gender, String adress, String department, String post, String dob, double salary) {
        this.staffID = staffID;
        this.name = name;
        this.gender = gender;
        this.adress = adress;
        this.department = department;
        this.post = post;
        this.dob = dob;
        this.salary = salary;
    }

    public String getStaffID() {
        return staffID;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getAdress() {
        return adress;
    }

    public String getDepartment() {
        return department;
    }

    public String getPost() {
        return post;
    }

    public String getDob() {
        return dob;
    }

    public double getSalary() {
        return salary;
    }
  
   
   public void displayInformation(){
       
       System.out.printf("%-6s %-20s %-12s %-10s %-12s %-20s %-10s %-10s %n",staffID,name,gender,adress,department,post,salary,dob);
       
       
   }
    
    
}
