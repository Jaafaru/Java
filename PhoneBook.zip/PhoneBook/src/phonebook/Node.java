/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook;

/**
 *
 * @author whitehacker
 */
public class Node {

    // Data fields for Node   

    private Contacts info;       // data stored in the node
    private Node link;         // link to next node

   // Methods
    // Constructors
    // postcondition: Creates a new empty node.
    public Node() {
        info = null;
        link = null;
    }

    // postcondition: Creates a new node storing obj.
    public Node(Contacts obj) {
        info = obj;
        link = null;
    }

   // postcondition: Creates a new node storing obj 
    //   and linked to node referenced by next.
    public Node(Contacts obj, Node next) {
        info = obj;
        link = next;
    }
    // accessors

    public Contacts getInfo() {
        return info;
    }

    public Node getLink() {
        return link;
    }

    // mutators
    public void setInfo(Contacts newInfo) {
        info = newInfo;
    }

    public void setLink(Node newLink) {
        link = newLink;
    }
}

