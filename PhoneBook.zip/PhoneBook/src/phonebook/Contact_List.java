/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook;

/*
 * @author whitehacker
 */
public class Contact_List {

    private Node head = null;
    private Node rear = null;
    private int num = 0;

    public Contact_List() {
        head = null;
        rear = null;
        num = 0;
    } // end default constructor

    public int getNum() {
        return num;
    }
    public boolean hasnext (Node cur) {
     return (cur.getLink() != null);
    
    }
    public void addCon(Contacts newEntry)  {
       Node newNode = new Node(newEntry);
        if (head == null)
         head = newNode;
        else 
       {
       Node current = head;
         // traversing nodes
       while (current.getLink() != null) // current.link != null
        current = current.getLink(); // current = current.link
        current.setLink(newNode.getLink()); // current.link= newNode
      }
     num++;
    }
     public void clear()
   {
	head = null;
	rear = null;
    } 
     public boolean isEmpty()
   {
	return (head == null );
   }

    public void removeCon(Contacts targ) {
        Contacts target = targ;
      if (head == null)
        System.out.println("Cannot delete data");
                else if (head.getInfo() == target)
                  head = head.getLink();
                else
                  {
              Node before = null;
              Node current= head;
 
           // current.info != target
             while ( (current.getInfo() != target) && (current != null) )
              {
             before = current;
            current = current.getLink(); // current = current.link
                     }
                  if (current.getInfo() == target)  // current.info == target
                  before.setLink(current.getLink()); // before.link = current.link
   
                   else
                 System.out.println("The target is not exists");
                      } 


                   }
           public Contacts search(Contacts acct)  {
	Node current = head;
        Contacts compare = null;
         while(current != null) {
           compare = current.getInfo();
//         if(acct.getAcctNo() == compare.getAcctNo()){
//             
//            current = current.getLink();
//            return compare;
//         }
       }           
        return compare;            
        }
//       public Contacts getFrontdata(Node it)  {
//	Contacts item = null;
//
//	if (!isEmpty())
//		item = it.getInfo();
//	return item;
//      }

    public Node getHead() {
        return head;
    }

    public Node getRear() {
        return rear;
    }
     
  }

