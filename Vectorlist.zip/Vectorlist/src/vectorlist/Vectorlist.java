/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vectorlist;

import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author whitehacker
 */
public class Vectorlist {

    static Vector<String> vec = new Vector<String>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        String item, delete;
        int i;

        System.out.println("Please enter item names, Enter done when you are finish!");
        item = in.next();

        while (!item.contains("done")) {
            vec.add(item);
            item = in.next();
        }
        displayVec();
        
        // this is to delete a Name from the Linkedlist
        System.out.println("Enter the item name that you want to delete for the Vector");
        delete = in.next();
        String u = "";
        for (i = 0; i < vec.size(); i++) {
            u = (String) vec.get(i);
            if (u.equalsIgnoreCase(delete)) {
                vec.remove(i);
                break;
            }

        }
        displayVec();
        
    }
//Display list Method
    public static void displayVec() {
        System.out.println("-----------------------------------");

        for (Object i : vec) {
            System.out.println(i);
        }
        System.out.println("The size of the Vector is: " + vec.size());
    }
}
