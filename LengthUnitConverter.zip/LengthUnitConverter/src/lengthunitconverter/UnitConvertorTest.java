/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lengthunitconverter;

import java.util.Scanner;

/**
 *
 * @author whitehacker
 */
public class UnitConvertorTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String lenghtType;
        double lengthNew = 0;
        double unitRate;
        Scanner scan = new Scanner(System.in);
        Scanner scan1 = new Scanner(System.in);
        Scanner scan2 = new Scanner(System.in);
        Scanner scan3 = new Scanner(System.in);
        UnitConvertor uc = new UnitConvertor();
        boolean run = true;

        do {

            try {
                System.out.println("\n Length-Unit Converter System");
                System.out.println("----------------------------------");
                System.out.println("Please choose your prefer action: ");
                System.out.println("1- Add new Unit. ");
                System.out.println("2- Convert Unit to other Unit");
                System.out.println("3- print all Unit");
                System.out.println("4- Enter \"4\" to  exit the System: ");

                switch (scan.nextInt()) {
                    case 1:    // adding new Unit and value Rate
                        System.out.println("Please enter length type: ");
                        lenghtType = scan1.next();

                        System.out.println("Please enter length value: ");
                        unitRate = scan3.nextFloat();

                        uc.addLenghtUnitRate(lenghtType, unitRate);
                        break;
                    case 2:     //Convert Unit
                        System.out.println("Please Enter lenght type for conversion: ");
                        lenghtType = scan2.next();

                        System.out.println("Please Enter the value you want to convert in number: ");
                        lengthNew = scan1.nextDouble();

                        unitRate = uc.convertUnit(lenghtType);
                        System.out.println("Value entered is " + unitRate + " converting Result is: " + (lengthNew * unitRate) +" "+lenghtType );
                        break;
                    case 3:     // print all Unit
                        System.out.println(uc.toString());
                        break;

                    case 4:     // exit the System
                        System.out.println("System closed");
                        run = false;
                        break;
                    default:
                        System.out.println("Action not found. Try again ");
                        break;
                }

            } catch (Exception e) {
                System.out.println(e);
            }

        } while (run == true);
    }

}
