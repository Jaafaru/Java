/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lengthunitconverter;

import java.util.Vector;
import java.util.regex.Pattern;

/**
 *
 * @author whitehacker
 */
public class UnitConvertor {
 /* OVERVEIW: LengthUnit Converter is an alterable class - it is able to add a Length and it's unit rate, 
    display the length and Exit the program
    
    Abstraction Function: 
    AF(C)= {for each c.lenghtType[i].lenghtType there exist c.unitRate[i].unitRate | 0<=i<c.UnitConvertorRecord.size}
	               
    *Rep Invariant:
    c.unit != Null
    for each integer i, 0<=i<c.unit , c.unit[i].lenghtType && c.unit[i].unitRate 
    lenghtType only english alphabet {a..z,A..Z}, unit and unitRate are numeric [1.....n]
    for each integer i , j. 0<=i<j<c.UnitConvertorRecord.size
    c.unit[i].lenghtType!= c.unit[j].lenghtType
    c.unit[i].unitRate!=c.unit[j].unitRate  */

    private Vector<UnitConvertorRecord> rep;
    private int i;
    private String currentlenghtType;
    private static final Pattern NUMBER = Pattern.compile("^\\d{2}$");

    public UnitConvertor() {
        rep = new Vector<UnitConvertorRecord>();
    }

    // Creator 
    public void addLenghtUnitRate(String lenghtType, double unitRate) throws Exception {
        // Modifies: this
        // EFFECTS: Add the LenghtType and rate to the rep

        rep.add(new UnitConvertorRecord(lenghtType, unitRate));
    }

    //Getter
    public double convertUnit(String lenghtType) throws Exception {
        // EFFECTS: return the value of the unit conversion

        i = lenghtType(lenghtType);
        if (i >= 0) {
            return rep.get(i).getUnitRate();
        } else {
            throw new Exception("\n This Length Type is not in the System \n ");
        }
    }

    //Observer
    public String toString() {
        // EFFECTS: print the value in a single String
        String u = "";
        for (i = 0; i < rep.size(); i++) {
            u = u + rep.get(i).getlenghtType() + " = " + rep.get(i).getUnitRate() + "\n";
        }
        return u;
    }

    private int lenghtType(String currentlenghtType) {
        for (int i = 0; i < rep.size(); i++) {
            if (currentlenghtType.equals(rep.get(i).getlenghtType())) {
                return i;
            }
        }
        return -1;
    }

    private int UnitRate(String UnitRate) {

        for (int i = 0; i < rep.size(); i++) {
            if (UnitRate.equals(rep.get(i).getUnitRate())) {
                return i;
            }
        }
        return -1;
    }

    public static final boolean isNumeric(String text) {
        return NUMBER.matcher(text).matches();
    }
}
