/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lengthunitconverter;

/**
 *
 * @author whitehacker
 */
public class UnitConvertorRecord {

    private String lenghtType;
    private double unitRate;

    public UnitConvertorRecord(String lenghtType, double unitRate) {
        this.lenghtType = lenghtType;
        this.unitRate = unitRate;
    }

    public String getlenghtType() {
        return lenghtType;
    }

    public double getUnitRate() {
        return unitRate;
    }

}
