/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telephone_directory;



public class Directory {
    private String surname;
    private String firstname;
    private String adress;
    private String phone;
    private String nationality;
    private String email;

    public Directory(String surname, String firstname, String adress, String phone, String nationality, String email) {
        this.surname = surname;
        this.firstname = firstname;
        this.adress = adress;
        this.phone = phone;
        this.nationality = nationality;
        this.email = email;
    }

    public String getSurname() {
        return surname;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getPhone() {
        return phone;
    }
    

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getAdress() {
        return adress;
    }

    public String getNationality() {
        return nationality;
    }

    public String getEmail() {
        return email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setEmail(String email) {
        this.email = email;
    }

      
}

